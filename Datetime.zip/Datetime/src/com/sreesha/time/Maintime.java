package com.sreesha.time;

public class Maintime {

	public static void main(String[] args) {
		new Mytimeframe();

	}

}
