package com.sreesha.time;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class PhotoFrame extends JFrame {
	int x=50, y=500;
	Image img, sun;
	PhotoFrame()
	{
		this.setSize(900, 900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("move-frame");
		this.setResizable(true);
		this.setVisible(true);
		
	}
	
	public void paint (Graphics g)
	{
		 img = new ImageIcon("images.jpg").getImage();
		 sun = new ImageIcon("sun.jpg").getImage();
		 g.drawImage(sun, 20, 20, null);
		 g.drawImage(img, x, y, null);
	
		    x=x+5;
			y=y-5;
			repaint();
			
			if(x==500 || y==50) {
				x=50;
				y=500;
				repaint();
			}
			
			try
			{	
				Thread.sleep(100);
				
			}
			catch(InterruptedException e) {
				System.out.println("exception in running");
			}
		}
	
	
	public static void main(String[] args) {
		new PhotoFrame();
		
	}
	
}
